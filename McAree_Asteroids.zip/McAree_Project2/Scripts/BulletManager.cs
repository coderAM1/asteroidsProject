﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletManager : MonoBehaviour
{
    public GameObject prefab;
    public List<GameObject> bulletList;
    public float bulletSpeed;
    public int fireRate;
    private int countDown;
    public float buffer;
	// Use this for initialization
	void Start ()
    {
        countDown = 0;
        bulletList = new List<GameObject>();
	}
	
	// Update is called once per frame
	void Update ()
    {
        AddBullet();
        MoveAllBullets();
        RemoveBullets();
        //Debug.Log("BulletList Contains: " + bulletList.Count);
	}

    /// <summary>
    /// adds bullets
    /// </summary>
    void AddBullet()
    {
        if(countDown < fireRate)
        {
            countDown++;
        }
        if(countDown >= fireRate && Input.GetKeyDown(KeyCode.Space))
        {
            bulletList.Add(Instantiate<GameObject>(prefab));
            bulletList[bulletList.Count - 1].transform.position = transform.position;
            bulletList[bulletList.Count - 1].GetComponent<Bullet>().direction = this.GetComponent<Vehicle>().direction;
            if(GetComponent<Vehicle>().UsingEnergy == true && GetComponent<Vehicle>().energy > 15)//used to fire in 6 directions using energy
            {
                for(int i = 1; i < 6; i++)
                {
                    bulletList.Add(Instantiate<GameObject>(prefab));
                    bulletList[bulletList.Count - 1].transform.position = transform.position;
                    bulletList[bulletList.Count - 1].GetComponent<Bullet>().direction = Quaternion.Euler(0, 0, 60 * i) *this.GetComponent<Vehicle>().direction;
                    GetComponent<Vehicle>().energy -= 15;
                }
            }
            countDown = 0;
        }
    }

    /// <summary>
    /// calls a method in the bullet class for every bullet and moves them
    /// </summary>
    void MoveAllBullets()
    {
        for (int i = 0; i < bulletList.Count; i++)
        {
            bulletList[i].GetComponent<Bullet>().MoveBullet(bulletSpeed);
        }
    }
    /// <summary>
    /// checks to see if the bullets are offscreen or if they toBegone boolean is true
    /// </summary>
    void RemoveBullets()
    {
        for (int i = 0; i < bulletList.Count; i++)
        {
            bulletList[i].GetComponent<Bullet>().OutOfBounds(buffer);
            if(bulletList[i].GetComponent<Bullet>().ToBegone == true)
            {
                Destroy(bulletList[i]);
            }
        }
        bulletList.RemoveAll(GameObject => GameObject.GetComponent<Bullet>().ToBegone == true);
    }
}
