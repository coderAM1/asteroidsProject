﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AsteroidManager : MonoBehaviour
{
    public List<GameObject> asteroidList = new List<GameObject>();//list for asteroids
    public GameObject[] prefabAsteroidL;//array for all asteroidL prefabs
    public GameObject[] prefabAsteroidS;//array for all asteroidS prefabs
    public float asteroidSpeed;//speed of the asteroid
    public float bufferDestroy;//buffer for the out of bounds check
    public float bufferSpawn;//buffer for the spawn, so it doesn't spawn on screen
    private int asteroidLCount = 0;//how many large asteroid are currently spawned
    public float gameTimer;//timer to check interval for spawning asteroids
    public List<Vector3> dir = new List<Vector3>();//list of direction
    public List<Vector3> pos = new List<Vector3>();//list of positions

	// Use this for initialization
	void Start ()
    {
        gameTimer = Time.realtimeSinceStartup + 2f;
    }
	
	// Update is called once per frame
	void Update ()
    {
        MoveAsteroid();
        AddAsteroidL();
        RemoveAsteroid();
    }
    /// <summary>
    /// checks to see if there are under 8 large asteroid
    /// and if 2 seconds have passed between adding the last one
    /// chooses a random asteroid from an array and instantiates it and adds it to a list
    /// </summary>
    void AddAsteroidL()
    {
        if(asteroidLCount < 8 && Time.unscaledTime >= gameTimer)
        {
            int rngAsteroid = Random.Range(0, prefabAsteroidL.Length);
            asteroidList.Add(Instantiate<GameObject>(prefabAsteroidL[rngAsteroid]));
            Camera camera = Camera.main;
            int rng = Random.Range(0, 2);
            float randomXcord;
            float randomYCord;
            //if zero it will either spawn left or right on screen,x-cord is random within two ranges, y-cord is random within one range
            if(rng == 0)
            {
                int rng2 = Random.Range(0, 2);
                if(rng2 == 0)
                {
                    randomXcord = Random.Range(camera.ScreenToWorldPoint(new Vector3(0, 0, 0)).x - bufferSpawn, camera.ScreenToWorldPoint(new Vector3(0, 0, 0)).x - (bufferSpawn / 2));
                }
                else
                {
                    randomXcord = Random.Range(camera.ScreenToWorldPoint(new Vector3(Screen.width, 0, 0)).x + (bufferSpawn / 2), camera.ScreenToWorldPoint(new Vector3(Screen.width, 0, 0)).x + bufferSpawn);
                }
                randomYCord = Random.Range(camera.ScreenToWorldPoint(new Vector3(0, 0, 0)).y - (bufferSpawn / 2), camera.ScreenToWorldPoint(new Vector3(0, Screen.height, 0)).y + (bufferSpawn / 2));
            }
            //else it will spawn up or down, x-cord is random within one range, y cord is random within 2
            else
            {
                int rng2 = Random.Range(0, 2);
                if (rng2 == 0)
                {
                    randomYCord = Random.Range(camera.ScreenToWorldPoint(new Vector3(0, 0, 0)).y - bufferSpawn, camera.ScreenToWorldPoint(new Vector3(0, 0, 0)).y - bufferSpawn/2);
                }
                else
                {
                    randomYCord = Random.Range(camera.ScreenToWorldPoint(new Vector3(0, Screen.height, 0)).y + bufferSpawn/2, camera.ScreenToWorldPoint(new Vector3(0, Screen.height, 0)).y + bufferSpawn);
                }
                randomXcord = Random.Range(camera.ScreenToWorldPoint(new Vector3(0, 0, 0)).x - (bufferSpawn), camera.ScreenToWorldPoint(new Vector3(Screen.width, 0, 0)).x + (bufferSpawn));
            }
            //sets the asteroid position and direction
            asteroidList[asteroidList.Count - 1].transform.position = new Vector3(randomXcord, randomYCord, 0);
            Vector3 dir = new Vector3(0, 0, 0) - asteroidList[asteroidList.Count - 1].transform.position;
            dir.Normalize();
            //randomize the angle by changed it randomly but it should always head somewhat towards the center, with a lot of variation
            float randomAngleChange = Random.Range(-30f, 30f);
            dir = Quaternion.Euler(0, 0, randomAngleChange) * dir;
            asteroidList[asteroidList.Count - 1].GetComponent<Asteroid>().direction = dir;
            asteroidList[asteroidList.Count - 1].GetComponent<Asteroid>().LargeAsteroid = true;
            asteroidLCount++;
            gameTimer = Time.realtimeSinceStartup + 2f; 
        }
    }

    /// <summary>
    /// method to be called when a large asteroid is destroyed
    /// adds two and takes the position and direction in order to have position and randomly change range
    /// </summary>
    /// <param name="dir"></param>
    /// <param name="pos"></param>
    void AddAsteroidS(Vector3 dir, Vector3 pos)
    {
        int rngAsteroid = Random.Range(0, prefabAsteroidS.Length);
        asteroidList.Add(Instantiate<GameObject>(prefabAsteroidS[rngAsteroid]));
        asteroidList[asteroidList.Count - 1].transform.position = pos;
        asteroidList[asteroidList.Count - 1].GetComponent<Asteroid>().LargeAsteroid = false;
        asteroidList[asteroidList.Count - 1].GetComponent<Asteroid>().direction = Quaternion.Euler(0, 0, -15) * dir;
        rngAsteroid = Random.Range(0, prefabAsteroidS.Length);
        asteroidList.Add(Instantiate<GameObject>(prefabAsteroidS[rngAsteroid]));
        asteroidList[asteroidList.Count - 1].transform.position = pos;
        asteroidList[asteroidList.Count - 1].GetComponent<Asteroid>().LargeAsteroid = false;
        asteroidList[asteroidList.Count - 1].GetComponent<Asteroid>().direction = Quaternion.Euler(0, 0, 15) * dir;
    }
    /// <summary>
    /// method to move all asteroids
    /// </summary>
    void MoveAsteroid()
    {
        for(int i = 0; i < asteroidList.Count; i++)
        {
            asteroidList[i].GetComponent<Asteroid>().MoveAsteroid(asteroidSpeed);
        }
    }
    /// <summary>
    /// removes an asteroid if toBegone is true, but if also large, will called AddAsteroidS() method
    /// </summary>
    void RemoveAsteroid()
    {
        for(int i = 0; i < asteroidList.Count; i++)
        {
            asteroidList[i].GetComponent<Asteroid>().OutOfBounds(bufferDestroy);
            if(asteroidList[i].GetComponent<Asteroid>().ToBegone == true)
            {
                if(asteroidList[i].GetComponent<Asteroid>().LargeAsteroid == true)
                {
                    pos.Add(asteroidList[i].transform.position);
                    dir.Add(asteroidList[i].GetComponent<Asteroid>().direction); 
                    asteroidLCount--;
                }
                Destroy(asteroidList[i]);
            } 
        }
        for(int i = 0; i < dir.Count; i++)
        {
            AddAsteroidS(dir[i], pos[i]);
        }
        dir.Clear();
        pos.Clear();
        asteroidList.RemoveAll(GameObject => GameObject.GetComponent<Asteroid>().ToBegone == true);
    }
}
