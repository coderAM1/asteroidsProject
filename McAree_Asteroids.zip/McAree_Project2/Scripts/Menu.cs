﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour
{
    /// <summary>
    /// method in a button to start the game
    /// </summary>
    public void StartGame()
    {
        SceneManager.LoadScene("GameScene");
    }
    /// <summary>
    /// method in a button to quit the game
    /// </summary>
    public void EndGame()
    {
        Application.Quit();
    }
}
