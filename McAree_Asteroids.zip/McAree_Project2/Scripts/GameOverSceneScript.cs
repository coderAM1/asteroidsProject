﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System;


public class GameOverSceneScript : MonoBehaviour
{
    public GameObject text;//3d text to be displayed
    private int highScore;//value for highscore
	// Use this for initialization
	void Start ()
    {
        CheckHighScore();
        text.GetComponent<TextMesh>().text = "Game Over!!!\n" + StaticDataHolder.Score + "\nHighScore:\n" + highScore;
    }
	
	// Update is called once per frame
	void Update ()
    {
        
	}
    /// <summary>
    /// checks current score against highscore
    /// </summary>
    void CheckHighScore()
    {
        /*string path = "Assets/HighScore";
        FileStream fileStream = new FileStream(path, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
        if(fileStream.)*/
        try
        {
            FileStream fileStream = new FileStream(Path.GetFullPath("HighScore.Txt"), FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
            try
            {
                StreamReader fileReader = new StreamReader(fileStream);
                string s = fileReader.ReadToEnd();
                StreamWriter fileWriter = new StreamWriter(fileStream);
                highScore = Convert.ToInt32(s);
                if (StaticDataHolder.Score > highScore)
                {
                    fileReader.Close();
                    fileWriter.WriteLine(StaticDataHolder.Score);
                    highScore = StaticDataHolder.Score;
                    fileWriter.Close();
                }
            }
            catch
            {
                StreamWriter fileWriter = new StreamWriter(fileStream);
                fileWriter.WriteLine(StaticDataHolder.Score);
                highScore = StaticDataHolder.Score;
                fileWriter.Close();
            }
            
            
            fileStream.Close();
        }
        catch
        {
            highScore = StaticDataHolder.Score;
            try
            {
                FileStream fileStream = new FileStream(Path.GetFullPath("HighScore.Txt"), FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
                StreamWriter fileWriter = new StreamWriter(fileStream);
                fileWriter.WriteLine(StaticDataHolder.Score);
                highScore = StaticDataHolder.Score;
                fileWriter.Close();
            }
            catch { }
        }
        
           
    }
}
