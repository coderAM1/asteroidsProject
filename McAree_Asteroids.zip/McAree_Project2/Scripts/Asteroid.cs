﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Asteroid : MonoBehaviour
{
    public Vector3 direction;//direction
    private bool toBegone;//if object should be destroyed
    public bool ToBegone { get { return toBegone; } set { toBegone = value; } }
    private bool largeAsteroid;//bool for if object is a large asteroid
    public bool LargeAsteroid { get { return largeAsteroid; } set { largeAsteroid = value; } }
    // Use this for initialization
    void Start ()
    {
        
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}
    /// <summary>
    /// moves the asteroid
    /// </summary>
    /// <param name="asteroidSpeed"></param>
    public void MoveAsteroid(float asteroidSpeed)
    {
        this.transform.position += direction * asteroidSpeed;
    }
    /// <summary>
    /// determines if asteroid is out of bounds
    /// </summary>
    /// <param name="buffer"></param>
    public void OutOfBounds(float buffer)
    {
        Camera camera = Camera.main;
        if (transform.position.x < camera.ScreenToWorldPoint(new Vector3(0, 0, 0)).x - buffer)
        {
            toBegone = true;
        }
        if (transform.position.x > camera.ScreenToWorldPoint(new Vector3(Screen.width, 0, 0)).x + buffer)
        {
            toBegone = true;
        }
        if (transform.position.y > camera.ScreenToWorldPoint(new Vector3(0, Screen.height, 0)).y + buffer)
        {
            toBegone = true;
        }
        if (transform.position.y < camera.ScreenToWorldPoint(new Vector3(0, 0, 0)).y - buffer)
        {
            toBegone = true;
        }
    }
}
