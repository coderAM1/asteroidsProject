﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public Vector3 direction;//direction
    private bool toBegone;//bool to determine if object should be destroyed
    public bool ToBegone { get { return toBegone; } set { toBegone = value; } }
	// Use this for initialization
	void Start ()
    {
        toBegone = false;
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}
    /// <summary>
    /// moves the bullet
    /// </summary>
    /// <param name="bulletSpeed"></param>
    public void MoveBullet(float bulletSpeed)
    {
        this.transform.position += direction * bulletSpeed;
    }
    /// <summary>
    /// checks to see if outofbounds, if so it makes toBegone = true
    /// </summary>
    /// <param name="buffer"></param>
    public void OutOfBounds(float buffer)
    {
        Camera camera = Camera.main;
        if (transform.position.x < camera.ScreenToWorldPoint(new Vector3(0, 0, 0)).x - buffer)
        {
            toBegone = true;
        }
        if (transform.position.x > camera.ScreenToWorldPoint(new Vector3(Screen.width, 0, 0)).x + buffer)
        {
            toBegone = true;
        }
        if (transform.position.y > camera.ScreenToWorldPoint(new Vector3(0, Screen.height, 0)).y + buffer)
        {
            toBegone = true;
        }
        if (transform.position.y < camera.ScreenToWorldPoint(new Vector3(0, 0, 0)).y - buffer)
        {
            toBegone = true;
        }
    }
}
