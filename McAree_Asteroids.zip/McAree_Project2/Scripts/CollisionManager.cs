﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CollisionManager : MonoBehaviour
{
    public List<GameObject> asteroidList;
    public List<GameObject> bulletList;
    public int pointTracker;
	// Use this for initialization
	void Start ()
    {
        pointTracker = 0;
	}
	
	// Update is called once per frame
	void Update ()
    {
        asteroidList = FindObjectOfType<AsteroidManager>().asteroidList;
        bulletList = FindObjectOfType<BulletManager>().bulletList;
        CollisionCheck();
        ChangeBackToStartScene();
	}

    /// <summary>
    /// checks the list of asteroid using bounding circle against bullets and playerVehicle
    /// </summary>
    void CollisionCheck()
    {
        for(int i = 0; i < asteroidList.Count; i++)
        {
            float asteroidRadius = asteroidList[i].GetComponentInChildren<SpriteRenderer>().bounds.size.x / 2;
            Vector3 asteroidCenter = asteroidList[i].GetComponentInChildren<SpriteRenderer>().bounds.center;
            for(int c = 0; c < bulletList.Count; c++)
            {
                float bulletRadius = bulletList[c].GetComponentInChildren<SpriteRenderer>().bounds.size.x / 2;
                Vector3 bulletCenter = bulletList[c].GetComponentInChildren<SpriteRenderer>().bounds.center;
                if(Mathf.Pow(bulletCenter.x - asteroidCenter.x,2) + Mathf.Pow(bulletCenter.y - asteroidCenter.y,2) < Mathf.Pow(bulletRadius + asteroidRadius, 2) && bulletList[c].GetComponent<Bullet>().ToBegone != true)
                {
                    asteroidList[i].GetComponent<Asteroid>().ToBegone = true;
                    bulletList[c].GetComponent<Bullet>().ToBegone = true;
                    if(asteroidList[i].GetComponent<Asteroid>().LargeAsteroid == true)
                    {
                        pointTracker += 20;
                    }
                    else
                    {
                        pointTracker += 50;
                    }
                }
            }
            Vector3 playerCenter = FindObjectOfType<Vehicle>().center;
            float playerRadius = FindObjectOfType<Vehicle>().radius;
            Debug.DrawLine(asteroidCenter, playerCenter);
            if (Mathf.Pow(playerCenter.x - asteroidCenter.x, 2) + Mathf.Pow(playerCenter.y - asteroidCenter.y, 2) < Mathf.Pow(playerRadius + asteroidRadius, 2) && FindObjectOfType<Vehicle>().CanBeHitAgain == true)
            {
                Debug.Log("has been hit");
                FindObjectOfType<Vehicle>().IsHit = true;
            }
        }
    }
    /// <summary>
    /// displays the current score
    /// </summary>
    void OnGUI()
    {
        // Change color
        GUI.color = Color.white;
        // Increase text size
        GUI.skin.box.fontSize = 20;
        GUI.Box(new Rect(Screen.width - 110, 10, 100, 50), "Score:\n" + pointTracker);
    }
    /// <summary>
    /// sets a static value equal to the score to be called later
    /// loads the gameover scene
    /// </summary>
    public void ChangeSceneGameOver()
    {
        StaticDataHolder.Score = pointTracker;
        SceneManager.LoadScene("GameOverScene");
    }
    /// <summary>
    /// changes back to the first scene if escape is pressed
    /// </summary>
    public void ChangeBackToStartScene()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            SceneManager.LoadScene("StartMenu");
        }
    }
}
 