﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class StaticDataHolder
{
    private static int score;//literally holds one value to be called in 2 scenes
    public static int Score
    {
        get { return score; }
        set { score = value; }
    }
}
