﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Vehicle : MonoBehaviour
{
    public float speed;    //how fast things move
    public float angleOfRotation; //degrees for positioning
    public Vector3 vehiclePosition;//vehicles position
    public Vector3 velocity;//velocity
    public Vector3 direction;//direction vehicle is facing
    public float angleChange;//how fas the angle changes per frame
    public float maxSpeed;//the max speed of the vehicle
    public Vector3 acceleration;//vector for when vehicle is accelerating
    public float rateOfAccel;//how fast the vehicle accelerates
    public float rateOfDec;//how fast/slow the vehicle decelerates
    public float buffer;//how much of a buffer zone before wrapping happens
    private bool isHit;//boolean for if the vehicle is hit
    public bool IsHit { get { return IsHit; } set { isHit = value; } }//get set
    private bool canBeHitAgain = true;//if the vehicle can be hit again
    public bool CanBeHitAgain { get { return canBeHitAgain; } }//get set
    private float counterToBeHitAgain = 0;//timer for beingable to be hit again
    private float counterBlink = 0;//timer for blink
    public int lifeCount = 3;//int for life counter
    private bool blink = false;//if the vehicle is currently being hidden
    public Vector3 center;//vector 3 for the center
    public float radius;//float for radius
    public float energy;//current value for energy
    public float maxEnergy;//maximum amount of energy
    private bool usingEnergy;//bool for if using energy
    private bool usingEnergyPreviousFramee;//bool for if using evergy the previous frame
    public bool UsingEnergy { get { return usingEnergy; } }
	// Use this for initialization
	void Start ()
    {
        canBeHitAgain = true;
        isHit = false;
        usingEnergy = false;
        usingEnergyPreviousFramee = usingEnergy;
        energy = 0;
	}
	
	// Update is called once per frame
	void Update ()
    {
        PowerUpStart();
        RotateVehicle();
        Drive();
        Wrap();
        TransformVehicle();
        DebugLines();
        Collisions();
        center = GetComponentInChildren<SpriteRenderer>().bounds.center;
        radius = GetComponentInChildren<SpriteRenderer>().bounds.size.x / 2;
	}
    /// <summary>
    /// handles the velocity with acceleration and deceleration
    /// </summary>
    public void Drive()
    {
        //"Acceleration"
        //speed += 0.01f;
        if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.W))
        {
            acceleration = rateOfAccel * direction;
            //calculate velocity
            acceleration.z = 0;
            velocity += acceleration;
            velocity = Vector3.ClampMagnitude(velocity, maxSpeed);
            vehiclePosition += velocity;
        }
        else
        {
            velocity = velocity * rateOfDec;
            if(velocity.magnitude < 0.000001f)
            {
                velocity.x = 0;
                velocity.y = 0;
            }
            vehiclePosition += velocity;
            vehiclePosition.z = 0f;
        }
        //calculate velocity
        
    }
    /// <summary>
    /// rotates the vehicle based on input of either left arrow key or right arrow key
    /// </summary>
    public void RotateVehicle()
    {
        //rotation
        //press left = rotate 1 deg to left
        //press right = rotate 1 deg to right
        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A))
        {
            //rotate direction
            angleOfRotation += angleChange;
            direction = Quaternion.Euler(0, 0, angleChange) * direction;
        }
        else if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))
        {
            angleOfRotation -= angleChange;
            direction = Quaternion.Euler(0, 0, angleChange * -1) * direction;
        }
    }
    /// <summary>
    /// changes the direction and the location of the vehicle
    /// </summary>
    public void TransformVehicle()
    {
        //'change rotation of sprite
        transform.rotation = Quaternion.Euler(0, 0, angleOfRotation);
        //change vehicle position
        transform.position = vehiclePosition;
    }
    /// <summary>
    /// wraps the vehicle when it goes out of bounds
    /// </summary>
    public void Wrap()
    {
        Camera camera = Camera.main;
        if (transform.position.x < camera.ScreenToWorldPoint(new Vector3(0, 0, 10f)).x - buffer)
        {
            vehiclePosition.x = camera.ScreenToWorldPoint(new Vector3(Screen.width, 0, 10f)).x + (buffer / 2);
        }
        if(transform.position.x > camera.ScreenToWorldPoint(new Vector3(Screen.width, 0, 10f)).x + buffer)
        {
            vehiclePosition.x = camera.ScreenToWorldPoint(new Vector3(0, 0, 10f)).x - (buffer / 2);
        }
        if(transform.position.y > camera.ScreenToWorldPoint(new Vector3(0, Screen.height, 10f)).y + buffer)
        {
            vehiclePosition.y = camera.ScreenToWorldPoint(new Vector3(0, 0, 10f)).y - (buffer / 2);
        }
        if(transform.position.y < camera.ScreenToWorldPoint(new Vector3(0, 0, 10f)).y - buffer)
        {
            vehiclePosition.y = camera.ScreenToWorldPoint(new Vector3(0, Screen.height, 10f)).y + (buffer/2);
        }
    }

    /*void RotateToMouseAndMove()
    {
        Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        float angleOfRotation = Mathf.Atan2(mousePos.y - vehiclePosition.y, mousePos.x - vehiclePosition.x) * Mathf.Rad2Deg + 90f;
        transform.rotation = Quaternion.Euler(0, 0, angleOfRotation);
        Vector3 normalizedVector = mousePos - vehiclePosition;
        normalizedVector.Normalize();
        vehiclePosition += normalizedVector * speed;
        vehiclePosition.z = 0f;
        transform.position = vehiclePosition;
    }*/
    void DebugLines()
    {
        Debug.DrawLine(vehiclePosition, vehiclePosition + direction, Color.yellow);
        Debug.DrawLine(vehiclePosition, vehiclePosition + velocity * 5f, Color.red);
        Debug.DrawLine(new Vector3(0, 0, 0), vehiclePosition, Color.blue);
    }

    /// <summary>
    /// Checks if a collision happened by boolean that is called true if hit in CollisionManager
    /// also if it has been hit, has a blinking effect to show invincibility 
    /// </summary>
    void Collisions()
    {
        if(canBeHitAgain == true)
        {
            GetComponentInChildren<SpriteRenderer>().enabled = true;
            if (isHit == true && usingEnergy != true)
            {
                isHit = false;
                lifeCount--;
                if(lifeCount <= 0)
                {
                    GameOver();
                }
                canBeHitAgain = false;
                counterToBeHitAgain = Time.time + 3f;
                counterBlink = Time.time + 0.1f;
                blink = false;
            }
        }
        else if( canBeHitAgain == false && usingEnergy != true && usingEnergyPreviousFramee != true)
        {
            if(Time.time >= counterToBeHitAgain)
            {
                canBeHitAgain = true;
            }
            else
            {
                if (blink == false)
                {
                    GetComponentInChildren<Renderer>().enabled = false;
                    blink = true;
                }
                else if(Time.time >= counterBlink)
                {
                    GetComponentInChildren<Renderer>().enabled = true;
                    blink = false;
                    counterBlink = Time.time + 0.1f;
                }
            }
        }
        else
        {
            GetComponentInChildren<SpriteRenderer>().color = Color.blue;
            //canBeHitAgain = true;
            energy -= 2;
        }
        usingEnergyPreviousFramee = usingEnergy;
    }
    /// <summary>
    /// called if lifecounter is less than zero
    /// </summary>
    void GameOver()
    {
        FindObjectOfType<CollisionManager>().ChangeSceneGameOver();
    }
    /// <summary>
    /// displays how many lifes are left
    /// </summary>
    void OnGUI()
    {
        // Change color
        GUI.color = Color.white;
        // Increase text size
        GUI.skin.box.fontSize = 20;
        GUI.Box(new Rect(10, 10, 100, 50), "Lives Left:\n" + lifeCount);
        if(energy > 0)
        {
            GUI.color = Color.red;
            GUI.Button(new Rect(10, Screen.height - (Screen.height * 0.05f), energy, Screen.height * .05f), "");
            
        }
    }
    /// <summary>
    /// if using energy;
    /// </summary>
    void PowerUpStart()
    {
        if(energy > 0 && Input.GetKey(KeyCode.LeftShift) && canBeHitAgain == true)
        {
            usingEnergy = true;
            canBeHitAgain = false;
        }
        else if(canBeHitAgain != true && energy > 0 && Input.GetKey(KeyCode.LeftShift) && usingEnergyPreviousFramee == true)
        {
            usingEnergy = true;
            canBeHitAgain = false;
        }
        else if(canBeHitAgain != true && usingEnergyPreviousFramee == true)
        {
            canBeHitAgain = true;
            usingEnergy = false;
            if(energy < maxEnergy)
            {
                energy += 1;
            }
            GetComponentInChildren<SpriteRenderer>().color = Color.white;
        }
        else
        {
            usingEnergy = false;
            if (energy < maxEnergy)
            {
                energy += 1;
            }
            GetComponentInChildren<SpriteRenderer>().color = Color.white;
        }
    }
}
